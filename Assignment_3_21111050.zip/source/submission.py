
import sys
sys.path.insert(0, '../KachuaCore/ast')

import kachuaAST as kAST
import graphviz

_univ=set()
_gen,_kill,_in,_out={},{},{},{}

class kachuaCommand:
	def __init__(self,stmt,relJmp=0):
		self.stmt=stmt
		self.relJmp=relJmp

class BasicBlock:               # This class represents a Basic Block
	def __init__(self,addr):      # address is the address of first statement in the basic block.
		self.items=[]               # items are all the statements in the basic block.
		self.addr=addr
		self.jmpAdd=None               # The address to which the jump would happen if the condition is true.
		self.next=None
		self.prev=set()
		self.pendown=False              # Is pendown just after the basic block.
		self._gen=set()
		self._kill=set()
		self._in=set()
		self._out=set()

def findLeaders(ir):            # Find Leaders and consider last block as exit block.
	isLeader=[1]+[0]*(len(ir))    # First Block will be anyway a leader.
	for i in range(len(ir)):
		addr, stmt, relJmp = i, ir[i][0], ir[i][1]
		_type= type(stmt)
		if relJmp != 1:             # If Relative Jump address is not 1, it is a Conditional/Unconditional statement
			isLeader[addr+relJmp]=1   # The Jump address will be a leader
			isLeader[addr+1]=1        # And also the immediate next instruction.
	return isLeader

def buildBasicBlks(isLeader,ir):     # Takes the leaders and builds basic blocks.
	basicBlks={}                       # Dictionary having first instruction address as the keys of basic blocks.
	for i in range(len(ir)):
		addr, stmt, relJmp = i, ir[i][0], ir[i][1]
		if isLeader[i]:                  # Add to basic block if it's a leader.
			if i !=0:
				basicBlks[block.addr]=block
			block=BasicBlock(addr)         # The address will act like id of basic block.
		block.items.append(kachuaCommand(stmt,relJmp))
		block.jmpAdd=addr+relJmp         # Jump address from that basic block is updated to the jump address given
	basicBlks[block.addr]=block        # by the last instruction in basic block
	endBlock=BasicBlock(len(ir))
	endBlock.items.append(kachuaCommand('End'))       # Add an End block
	basicBlks[endBlock.addr]=endBlock
	return basicBlks	

def buildTree(cfg):
	for node in cfg:                           # For each node in the Control Flow Graph, Concatenate all the items
		items='\n'.join([str(item.stmt) for item in cfg[node].items])         # in one basic block together and make a graph node to draw.
		jmpaddr=cfg[node].jmpAdd
		next=cfg[node].next
		if jmpaddr:
			cfg[jmpaddr].prev.add(node)
		if items == 'End':
			continue
		nodes=list(cfg.keys())                     # Finally connect the default straight flow of CFG.
	for i in range(len(nodes)-1):
		if 'False' == str(cfg[nodes[i]].items[-1].stmt):       # False will always jump, so no default edge.
			continue
		cfg[nodes[i]].next=nodes[i+1]            # Add default edges.nodes[i+1]
		cfg[nodes[i+1]].prev.add(nodes[i])
	return cfg

def genCFG(ir):
	# your codde here
	isLeader=findLeaders(ir)          # Find Leaders
	basicBlks=buildBasicBlks(isLeader,ir)   # Identify and create basic blocks
	cfg=buildTree(basicBlks)
	return cfg

def dumpCFG(cfg):
	# dump CFG to a dot file
	edges=[]                                   # Set of edge1 ==> edge2 which graphViz will draw.
	graph = graphviz.Digraph(format='png')
	for node in cfg:                           # For each node in the Control Flow Graph, Concatenate all the items
		items='\n'.join([str(item.stmt) for item in cfg[node].items])         # in one basic block together and make a graph node to draw.
		jmpaddr=cfg[node].jmpAdd
		next=cfg[node].next
		graph.node(str(node),items)              # node == address of first statement in basic block
		if items == 'End':
			continue
		edges.append((str(node),str(jmpaddr)))   # Add node, jump Address pair to draw an edge
		if next is None:
			continue
		edges.append((str(node),str(next)))
	for e1,e2 in set(edges):                   # Finally, draw the directed CFG using the stored edges.
		graph.edge(e1,e2)
	graph.render('testcase',view=True)    # Render the graph as a png image and show it.

def getUSet(ir):
	_univ=set()
	for stmt in ir:
		if type(stmt[0]) is kAST.AssignmentCommand and str(stmt[0]) not in [str(item) for item in _univ]:   # == operator currently not supported in kachua framework.
			_univ.add(stmt[0])
	return _univ

def getGKSet(cfg,_univ):
	for node in cfg:
		for item in cfg[node].items:
			if type(item) is kAST.AssignmentCommand:
				cfg[node]._gen.add(item)
				for defn in _univ:
					if str(defn.lvar)==str(item.lvar):
						cfg[node]._kill.add(defn)
		#print('Gen Kill:',[str(item) for item in cfg[node]._gen],[str(item) for item in cfg[node]._kill])
	return cfg


def killAndReplace(code,curr,addups,pendown):   # Kill previous move statements and replace with one.
	stmt=kAST.MoveCommand(curr,'+'.join(addups)) if pendown else kAST.MoveCommand(curr[0],''.join(addups))
	code.append(kachuaCommand(stmt,1))
	addups.clear()
	return stmt,code,addups

def getStatement(curr,code,addups,stmt=''	):    # Get statement in kachuaAST data types.
	if addups:
		stmt=kAST.MoveCommand(curr,''.join(addups))
		stmt=kachuaCommand(stmt,1)
		code.append(stmt)
		addups.clear()
	return stmt,code,addups

def killRed(items,pendown=True):  # -----Pass2-----
	addups,code=[],[]
	sign1={'forward': '+','backward': '+', 'left': '+', 'right': '+'}
	sign2={'forward': '+','backward': '-', 'left': '-', 'right': '+'}
	types={'forward': 'forward','backward': 'forward', 'left': 'right', 'right': 'right'}
	curr= 'forward'
	for item in items:
		if type(item.stmt) is kAST.PenCommand:
			pendown= item.stmt.status == 'pendown'
			stmt,code,addups=getStatement(curr,code,addups)
		elif type(item.stmt) is kAST.MoveCommand:
			if pendown:
				if item.stmt.direction != curr:
					code.append(kachuaCommand(kAST.AssignmentCommand('t',str(0)),1))
					stmt,code,addups=getStatement(curr,code,addups)
					curr=item.stmt.direction
				addups.append(sign1[curr]+str(item.stmt.expr))
			else:
				if types[item.stmt.direction] != curr:
					code.append(kachuaCommand(kAST.AssignmentCommand('t',str(0)),1))
					stmt,code,addups=getStatement(curr,code,addups)
					curr=types[item.stmt.direction]
				addups.append(sign2[item.stmt.direction]+str(item.stmt.expr))
			continue
		elif type(item.stmt) is kAST.ConditionCommand:
			stmt,code,addups=getStatement(curr,code,addups)
		else:
			stmt,code,addups=getStatement(curr,code,addups)
		code.append(item)
	return pendown,code

def updateStatus(items,pendown=True):
	for item in items:
		if type(item.stmt) is kAST.PenCommand:
			pendown= item.stmt.status == 'pendown'
	return pendown

def applyJoinFunc(cfg):
	pendown=True
	for node in cfg:
		for prevNode in cfg[node].prev:
			pendown= pendown and cfg[prevNode].pendown
	cfg[node].pendown = pendown
	return cfg
		
def optLocal(cfg):
	for node in cfg:
		cfg[node].pendown=updateStatus(cfg[node].items)  # Pass1
	cfg=applyJoinFunc(cfg)                             # Apply join operator for pendown status as logical AND for all previous nodes.
	
	for node in cfg:                                   # Pass2
		cfg[node].pendown,cfg[node].items=killRed(cfg[node].items)  # Kill redundant move statements in pass2.
	return cfg
		

def getIR(cfg):
	irfile=open('ir.txt','w')
	irtext=''
	ir=[]
	for node in cfg:
		for item in cfg[node].items:
			irtext+='{} {} [{}]\n'.format(str(len(ir)),item.stmt,item.relJmp)
			ir.append((item.stmt,item.relJmp))
	irfile.write(irtext)
	irfile.close()
	return ir

def optimize(ir):    # create optimized ir in ir2
	cfg=genCFG(ir)
	cfg=optLocal(cfg)  # Optimize local basic blocks and pass the output to 2nd PASS.
	dumpCFG(cfg)
	ir=getIR(cfg)
	
	ir2 = ir # currently no oprimization is enabled
	return ir2
