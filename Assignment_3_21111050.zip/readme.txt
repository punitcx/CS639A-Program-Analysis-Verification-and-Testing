Requirements:
1. Python3, antlr4-python3-runtime.
2. Code must be ran in bash shell for proper output.

Installations:
If the above requirements are not installed, install them using:
apt install python3
pip install antlr4-python3-runtime==4.7.2
sudo apt-get install python3-tk 

Running Instructions:
1. Run kachua.py with parameter as a turtle file to process using:
	./kachua.py -O turtlefile.tl
	Ex: ./kachua.py -O testcases/testcase1.tl

Working:
	kachua.py will invoke functions from submission.py:
	1. genCFG will generate CFG by identifying leaders and creating basic blocks and will
	generate the CFG as a python Dictionary.
	2. dumpCFG will take the basic blocks and add edges to it. 
	3. optimize will optimise the ir using local and global optimization from basic blocks.

Some complex testcases covering a variety of inputs are provided in the directory testcases.
Corresponding expected output for ir will be stored in the current directory.

Assumptions:
1. submission.py is present in current directory at the time of running, where other required
kachua packages also reside(like ast,parser etc)
2. submission.py is present in the source directory which needs to be moved to main build directory
where other packages are present as mentioned in (1) and testcases are in the testcases directory.
