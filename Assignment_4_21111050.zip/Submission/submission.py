import random as r
import sys
sys.path.insert(0, "KachuaCore/interfaces/")
from interfaces.fuzzerInterface import *

# make sure dot or xdot works and grapviz is installed.
# Uncomment for Assignment-2
# sys.path.append("KachuaCore/kast")
# import kast.kachuaAST
# import graphviz


class CustomCoverageMetric(CoverageMetricBase):
    # Statements covered is used for 
    # coverage information.
    def __init__(self):
        super().__init__()

    # TODO : Implement this
    def compareCoverage(self, curr_metric, total_metric):
        # must compare curr_metric and total_metric
        # True if Improved Coverage else False
        print("[+]Compare Current Metric {} {}, Total Metric {} {}".format(curr_metric,len(curr_metric),total_metric,len(total_metric)))
        coverage_imp = True if len(curr_metric) >= len(total_metric) else False
        return coverage_imp

    # TODO : Implement this
    def updateTotalCoverage(self, curr_metric, total_metric):
        # Compute the total_metric coverage and return it (list)
        # this changes if new coverage is seen for a 
        # given input.
        if len(curr_metric) >= len(total_metric) : return curr_metric
        return total_metric

def bitFlip(var):
	loc=r.randint(1,7)
	var='{:08b}'.format(var)
	var=list(var)
	var[loc]=str(int(var[loc]=='0'))
	var[0]= '+' if r.randint(0,4) else '-'
	var=''.join(var)
	return int(var,2)
	
def nBitFlip(var):
	n=r.randint(1,7)
	for _ in range(n):
		var=bitFlip(var)
	return var

def applyMutation(input_data):
	for key in input_data.data:
		meth=r.randint(0,7)
		var=input_data.data[key]
		if var == 0 : var = r.randint(0,100)
		if meth <= 1: var=bitFlip(var)
		if 2 <= meth <= 3: var=nBitFlip(var)
		if meth == 4: var=int(var+ var*0.3)
		if meth == 5: var=int(var- var*0.3)
		if meth == 6: var=int(var*2)
		if meth == 7: var=int(var/2)
		
		input_data.data[key]=var
	return input_data

class CustomMutator(MutatorBase):
		def __init__(self):
				pass

		# TODO : Implement this
		def mutate(self, input_data, coverageInfo, irList):
			# Mutate the input data and return it
			# coverageInfo is of type CoverageMetricBase
			# Don't mutate coverageInfo
			# irList : List of IR Statments (Don't Modify)
			# input_data.data -> type dict() with {key : variable(str), value : int}
			# must return input_data after mutation.
			applyMutation(input_data)
			return input_data

# Reuse code and imports from 
# earlier submissions (if any).
def genCFG(ir):
    # your code here
    cfg = None
    return cfg

def dumpCFG(cfg):
    # dump CFG to a dot file
    pass

def optimize(ir):
    # create optimized ir in ir2
    ir2 = ir # currently no oprimization is enabled
    return ir2
