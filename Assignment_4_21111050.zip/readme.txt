Requirements:
1. Python3, antlr4-python3-runtime.
2. Code must be ran in bash shell for proper output.

Installations:
If the above requirements are not installed, install them using:
apt install python3
pip install antlr4-python3-runtime==4.7.2
sudo apt-get install python3-tk 

Running Instructions:
1. Run kachua.py with parameter as a turtle file to fuzz using:
	Ex: ./kachua.py -z testcases/testcase1.tl -t 60 -d "{'vara':34, 'varb':8}"

Working:
	kachua.py will invoke functions from submission.py:
	1. compareCoverage will see if the coverage is improved and return True or False.
	2. updateTotalCoverage will update the coverage to current coverage if the coverage is improved.
	3. mutate will apply mutation on the input_data based on the following :
	For each input variable:
		It randomly chooses a method to mutate the input in some priority where the methods are:
		a. bitflip(flip random single bit for each variable)
		b. n-bitflip ( flip random no. of bits for each variable)
		c. add some constant( 30% of the actual value)
		d. subtract some constatn( 30 % of the actual value)
		c. multiply by 2
		d. divide by 2.
Cases:
	Some complex testcases covering a variety of inputs are provided in the directory testcases.
	1] ./kachua.py -z testcases/testcase1.tl -t 60 -d "{'vara':50, 'varb':8}"   # Covered 34
	2] ./kachua.py -z testcases/testcase2.tl -t 30 -d "{'x':0, 'y':8, 'z':10}"  # Covered 11
	3] ./kachua.py -z testcases/testcase3.tl -t 30 -d "{'vara':4, 'varb':5, 'varc':7 }" # Covered 31
	4] ./kachua.py -z testcases/testcase4.tl -t 10 -d "{'x':4, 'y':6, 'z':17,'shape':3 }" # Covered 19
	5] ./kachua.py -z testcases/testcase5.tl -t 10 -d "{'x':23, 'y':6,'ts':3 }" # Covered 22

Limitations:
	1.The fuzzer will work with small inputs as bit flip mutation is designed for 8 bit input. So any input in the range -127 to 128 will work.
	This was done to make the implementation of the fuzzer easier.
	2. All the move statements like forward :x, forward 100, left 45 etc. have been simplified to small movements like forward 5, forward 1, left 4 etc. for demonstration purpose since it doesn't make any difference( because those instructions will still get executed, but we'll be able to fuzz in less time).

Assumptions:
1. submission.py is present in the folder Submission in the current directory at the time of running, where other required
kachua packages also reside(like kachua.py,fuzzer etc)
2. submission.py is present in the source directory which needs to be moved to main build directory
where other packages are present as mentioned in (1) and testcases are in the testcases directory.
