import sys
sys.path.insert(0, './ast')

import kachuaAST as kAST        # Import kachuaAST and GraphViz
import graphviz

class BasicBlock:               # This class represents a Basic Block
	def __init__(self,addr):      # address is the address of first statement in the basic block.
		self.items=[]               # items are all the statements in the basic block.
		self.addr=addr
		self.jmpAdd=0               # The address to which the jump would happen if the condition is true.

def findLeaders(ir):            # Find Leaders and consider last block as exit block.
	isLeader=[1]+[0]*(len(ir))    # First Block will be anyway a leader.
	for i in range(len(ir)):
		addr, stmt, relJmp = i, ir[i][0], ir[i][1]
		_type= type(stmt)
		if relJmp != 1:             # If Relative Jump address is not 1, it is a Conditional/Unconditional statement
			isLeader[addr+relJmp]=1   # The Jump address will be a leader
			isLeader[addr+1]=1        # And also the immediate next instruction.
	return isLeader

def buildBasicBlks(isLeader,ir):     # Takes the leaders and builds basic blocks.
	basicBlks={}                       # Dictionary having first instruction address as the keys of basic blocks.
	for i in range(len(ir)):
		addr, stmt, relJmp = i, str(ir[i][0]), ir[i][1]
		if isLeader[i]:                  # Add to basic block if it's a leader.
			if i !=0:
				basicBlks[block.addr]=block
			block=BasicBlock(addr)         # The address will act like id of basic block.
		block.items.append(stmt)
		block.jmpAdd=addr+relJmp         # Jump address from that basic block is updated to the jump address given
	basicBlks[block.addr]=block        # by the last instruction in basic block
	endBlock=BasicBlock(len(ir))
	endBlock.items.append('End')       # Add an End block
	basicBlks[endBlock.addr]=endBlock
	return basicBlks	

def genCFG(ir):
    # your code here
    isLeader=findLeaders(ir)          # Find Leaders
    cfg=buildBasicBlks(isLeader,ir)   # Identify and create basic blocks
    return cfg

def dumpCFG(cfg):
  # dump CFG to a dot file
	graph = graphviz.Digraph(format='png')
	edges=[]                                   # Set of edge1 ==> edge2 which graphViz will draw.
	for node in cfg:                           # For each node in the Control Flow Graph, Concatenate all the items
		items='\n'.join(cfg[node].items)         # in one basic block together and make a graph node to draw.
		jmpaddr=cfg[node].jmpAdd
		graph.node(str(node),items)              # node == address of first statement in basic block
		if items == 'End':
			continue
		edges.append((str(node),str(jmpaddr)))   # Add node, jump Address pair to draw an edge
		print(node,items,jmpaddr)
	
	nodes=list(cfg.keys())                     # Finally connect the default straight flow of CFG.
	for i in range(len(nodes)-1):
		if 'False' in cfg[nodes[i]].items:       # False will always jump, so no default edge.
			continue
		node1=str(nodes[i])                      # Add default edges.
		node2=str(nodes[i+1])
		edges.append((node1,node2))
	for e1,e2 in set(edges):                   # Finally, draw the directed CFG using the stored edges.
		graph.edge(e1,e2)
	graph.render('testcase',view=True)    # Render the graph as a png image and show it.
