Requirements:
1. Python3, antlr4-python3-runtime.
2. Code must be ran in bash shell for proper output.

Installations:
If the above requirements are not installed, install them using:
apt install python3
pip install antlr4-python3-runtime==4.7.2
sudo apt-get install python3-tk 

Running Instructions:
1. Run kachua.py with parameter as a turtle file to process using:
	./kachua.py turtlefile.tl
	Ex: ./kachua.py testcases/testcase1.tl

Working:
	kachua.py will invoke functions from submission.py:
	1. genCFG will generate CFG by identifying leaders and creating basic blocks and will
	generate the CFG as a python Dictionary.
	2. dumpCFG will take the basic blocks and add edges to it. Further it will use the 
	GraphViz utility to save the CFG in image(png) format.

Some complex testcases covering a variety of inputs are provided in the directory testcases.
Corresponding expected output for CFG's in png image format are provided in testcases.

Assumptions:
1. submission.py is present in current directory at the time of running, where other required
kachua packages also reside(like ast,parser etc)
2. submission.py is present in the source directory which needs to be moved to main build directory
where other packages are present as mentioned in (1) and testcases are in the testcases directory.
