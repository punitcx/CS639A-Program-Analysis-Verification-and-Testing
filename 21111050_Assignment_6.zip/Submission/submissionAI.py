import json
import copy
import math
import sys
from typing import overload

sys.path.insert(0, "../KachuaCore/")
import cfg.kachuaCFG as cfgK
import cfg.cfgBuilder as cfgB
from interfaces.abstractInterpretationInterface import  *
import kast.kachuaAST as kachuaAST
import abstractInterpretation as AI

'''
    Class for interval domain
'''
class Interval(abstractValueBase):

    '''Initialize abstract value'''
    def __init__(self, data):
        self.a,self.b=data

    '''To display abstract values'''
    def __str__(self):
        return "[{},{}]".format(self.a,self.b)

    '''To check whether abstract value is bot or not'''
    def isBot(self):
        return self.a > self.b

    '''To check whether abstract value is Top or not'''
    def isTop(self):
        return (self.a == -inf) and (self.b == inf)

    '''Implement the meet operator'''
    def meet(self, other):
        if self.isBot() or other.isBot():
          self.a, self.b = 1,-1
          return
        c,d = other.a,other.b
        if c >= self.a and c <= self.b:
            self.a,self.b = c,min([self.b,d])
        elif self.a >= c and self.a <= d:
            self.a,self.b = self.a,min([self.b,d])
        else:
            self.a,self.b = (1,-1)
        #print("Meet {}".format((self.a,self.b),other))

    '''Implement the join operator'''
    def join(self, other):
        if other.isBot(): return
        if self.isBot():
          self.a , self.b = other.a, other.b
          return
        c,d = other.a,other.b
        self.a,self.b= min([self.a,c]), max([self.b,d])
        #print("Join {} {}".format((self.a,self.b),other))

    '''partial order with the other abstract value'''
    def __le__(self, other):
        c,d = other.a, other.b
        #print("le {}".format((self.a,self.b),other))
        return (self.a >= c) and (self.b <=d)

    '''equality check with other abstract value'''
    def __eq__(self, other):
        c,d = other.a,other.b
        #print("eq {}".format((self.a,self.b),other))
        return (self.a == c) and (self.b == d)

    '''
        Add here required abstract transformers
    '''
    def Add(self,other):           # Addition of Abstract Values
        c,d = other.a,other.b
        self.a+= c                 # [a,b] + [c,d] = [a+c,b+d]  Min will be a+c and Max will be b+d
        self.b+= d
    def Sub(self,other):           # Subtraction of Abstract Values
        c,d = other.a,other.b
        self.a-= d                 # [a,b] - [c,d] = [a-d,b-c]  Min will be a-d and Max will be b-c
        self.b-= c
    def isConst(self):
        return self.a == self.b

inf = 99999

def docopy(obj):
	return copy.deepcopy(obj)

def absNum(num):
    return Interval((num,num))

def absVar(varname,absValues):
	if varname not in absValues.keys() : absValues[varname] = Interval((-inf,inf))
	absvar = docopy(absValues[varname])
	return absvar

def absSum(left,right,absValues):
    left=evaluate(left,absValues)
    right=evaluate(right,absValues)
    left=docopy(left)
    left.Add(right)
    return left

def absDiff(left,right,absValues):
    left=evaluate(left,absValues)
    right=evaluate(right,absValues)
    left=docopy(left)
    left.Sub(right)
    return left

def evaluate(expr,absValues):
    #print("type {}".format(type(expr)))
    if type(expr) == kachuaAST.Num:
        absVal=absNum(int(expr.val))                   # Interval like [10,10]
    elif type(expr) == kachuaAST.Var:
        absVal=absVar(expr.varname,absValues)
    elif type(expr) == kachuaAST.Sum:
        absVal = absSum(expr.lexpr,expr.rexpr,absValues)
    elif type(expr) == kachuaAST.Diff:
        absVal = absDiff(expr.lexpr,expr.rexpr,absValues)
    return absVal

def processAssg(lvar,rexpr,absValues):               
    absValues[lvar.varname] = evaluate(rexpr,absValues)
    #print("Assignment Done {}".format(['{}:{}'.format(k,absValues[k]) for k in absValues])) 
    return [absValues]


def processMove(move,amount,absValues):
    _dir = absValues['_dir']
    _tx, _ty = absValues['_tx'], absValues['_ty']
    tx1 , tx2 = docopy(_tx), docopy(_tx)
    ty1 , ty2 = docopy(_ty), docopy(_ty)
    movement=evaluate(amount,absValues)
    if 0 in _dir and 2 not in _dir:
      tx1.Add(movement) if move == 'forward' else tx1.Sub(movement)
    if 0 not in _dir and 2 in _dir:
      tx2.Sub(movement) if move == 'forward' else tx2.Add(movement)
      tx1 = tx2
    if 0 in _dir and 2 in _dir:
      tx1.join(tx2)      
    
    if 1 in _dir and 3 not in _dir:
      ty1.Add(movement) if move == 'forward' else ty1.Sub(movement)
    if 1 not in _dir and 3 in _dir:
      ty2.Sub(movement) if move == 'forward' else ty2.Add(movement)
      ty1 = ty2
    if 1 in _dir and 3 in _dir:
      ty1.join(ty2)
    
    absValues['_tx'],absValues['_ty'] = tx1,ty1
    return [absValues]
	
def processRotation(move,amount,absValues):
    _dir = absValues['_dir']
    amount = int(amount.val)/90
    _dir = [int(d + amount)%4 for d in _dir] if move == 'left' else [int(d - amount)%4 for d in _dir] 
    #print("Amount {} _dir {}".format(amount,_dir))
    absValues['_dir'] = set(_dir)
    return [absValues]

def updateEQ(leftvar,left,right,absValues):
    left = evaluate(left,absValues)
    right = evaluate(left,absValues)
    _true = left.meet(right)
    _false = docopy(right)
    absValues1, absValues2 = docopy(absValues), docopy(absValues)
    absValues1[leftvar], absValues2[leftvar] = _true, _false
    if _true.isBot() : absValues1['_tx'], absValues1['_ty'], absValues1['_dir'] = Interval((1,-1)), Interval((1,-1)), set()
    if _false.isBot() : absValues2['_tx'], absValues2['_ty'], absValues2['_dir'] = Interval((1,-1)), Interval((1,-1)), set()
    print("Equality _true {} _false {}".format(_true,_false))
    return [absValues1,absValues2]

def updateNEQ(leftvar,left,right,absValues):
    absValues2,absValues1 = updateEQ(leftvar,left,right,absValues)
    return [absValues1,absValues2]

def updateLT(leftvar,left,right,absValues):
    _true = evaluate(left,absValues)
    right = evaluate(right,absValues)
    _false = docopy(_true)
    _true.b = min([_true.b,right.b-1])
    _false.a = max([_false.a,right.a])
    absValues1, absValues2 = docopy(absValues), docopy(absValues)
    absValues1[leftvar], absValues2[leftvar] = _true, _false
    if _true.isBot() : absValues1['_tx'], absValues1['_ty'], absValues1['_dir'] = Interval((1,-1)), Interval((1,-1)), set()
    if _false.isBot() : absValues2['_tx'], absValues2['_ty'], absValues2['_dir'] = Interval((1,-1)), Interval((1,-1)), set()
    return [absValues1,absValues2]

def updateGT(leftvar,left,right,absValues):
    _true = evaluate(left,absValues)
    right = evaluate(right,absValues)
    _false = docopy(_true)
    _true.a = max([_true.a,right.a+1])
    _false.b = min([_false.b,right.b])
    absValues1, absValues2 = docopy(absValues), docopy(absValues)
    absValues1[leftvar], absValues2[leftvar] = _true, _false
    if _true.isBot() : absValues1['_tx'], absValues1['_ty'], absValues1['_dir'] = Interval((1,-1)), Interval((1,-1)), set()
    if _false.isBot() : absValues2['_tx'], absValues2['_ty'], absValues2['_dir'] = Interval((1,-1)), Interval((1,-1)), set()
    return [absValues1,absValues2]

def updateGTE(leftvar,left,right,absValues):
    absValues2,absValues1 = updateLT(leftvar,left,right,absValues)
    return [absValues1,absValues2]

def updateLTE(leftvar,left,right,absValues):
    absValues2,absValues1 = updateGT(leftvar,left,right,absValues)
    return [absValues1,absValues2]

def intersect(absValues1,absValues2):
    meetVal = absValues1
    for absvar in absValues2:
      if absvar not in meetVal.keys():
        meetVal[absvar] = absValues2[absvar]
      if type(meetVal[absvar]) == Interval:
        meetVal[absvar].meet(absValues2[absvar])
    return meetVal

def union(absValues1,absValues2):
    joinVal = absValues1
    for absvar in absValues2:
      if absvar not in joinVal.keys():
        joinVal[absvar] = absValues2[absvar]
      if type(joinVal[absvar]) == Interval:
        joinVal[absvar].join(absValues2[absvar])
    return joinVal

def updateAnd(leftvar,left,right,absValues):
    #print(type(left), type(right))
    _true1, _false1 = processCondition(left,absValues)
    _true2, _false2 = processCondition(right,absValues)
    
    _true = intersect(_true1,_true2)
    _false = union(_false1,_false2)
    return [_true,_false]

def updateOr(leftvar,left,right,absValues):
    #print(type(left), type(right))
    _true1, _false1 = processCondition(left,absValues)
    _true2, _false2 = processCondition(right,absValues)
    
    _true = union(_true1,_true2)
    _false = intersect(_false1,_false2)
    return [_true,_false]
  
def processCondition(ins,absValues):
    if str(ins) in ['False','True'] : return [absValues,absValues]
    if type(ins) == kachuaAST.ConditionCommand:
      left, op, right = ins.cond.lexpr, ins.cond.symbol, ins.cond.rexpr
    else:
      left, op, right = ins.lexpr, ins.symbol, ins.rexpr
    leftvar = str(left)
    #print("Condition",leftvar, left, op, right,type(left))
    if '__rep_counter' in leftvar : return [absValues,absValues]
    if op == '==':
    	outVal = updateEQ(leftvar,left,right,absValues)
    elif op == '!=':
    	outVal = updateNEQ(leftvar,left,right,absValues)
    elif op == '<':
    	outVal = updateLT(leftvar,left,right,absValues)
    elif op == '>':
    	outVal = updateGT(leftvar,left,right,absValues)
    elif op == '<=':
    	outVal = updateLTE(leftvar,left,right,absValues)
    elif op == '>=':
    	outVal = updateGTE(leftvar,left,right,absValues)
    elif op == 'and':
      outVal = updateAnd(leftvar,left,right,absValues)
    elif op == 'or':
      outVal = updateOr(leftvar,left,right,absValues)
    return outVal

def processGoto(x,y,absValues):
  _true = docopy(absValues)
  _true['_tx'], _true['_ty'] = absNum(x), absNum(y)
  return [_true]

def processIns(absValues,ins,instype):               # For updating abstract values according to given instruction
    if '__rep_counter' in str(ins):
      outVal = [absValues,absValues]
    elif instype == kachuaAST.AssignmentCommand:      # If it's an assignment to a variable
        lvar, rexpr = ins.lvar, ins.rexpr
        outVal=processAssg(lvar,rexpr,absValues)     # Update abstract value by checking rhs.
    elif instype == kachuaAST.MoveCommand:          # Consists of moves forward/backward and rotations left/right
        move=ins.direction
        amount=ins.expr
        #print("Direction {} expr {}".format(move,amount))
        if move in ['forward','backward']:                     # Update abstract _tx and _ty of turtle position
            outVal = processMove(move,amount,absValues)
        elif move in ['left','right']:                         # Update abstract _dir of turtle.
            outVal = processRotation(move,amount,absValues)
    elif instype == kachuaAST.ConditionCommand:
        outVal=processCondition(ins,absValues)
    elif instype == kachuaAST.GotoCommand:
      outVal = processGoto(ins.xcor,ins.ycor,absValues)
    else:
      print("Instruction {}".format(instype))
      outVal = [absValues]
    return outVal

def printDicts(inVal):
  for d in inVal:
      print(["{}:{}".format(key,d[key]) for key in d.keys()], sep = " ")

class ForwardAnalysis():
    def __init__(self):
        pass

    '''
        This function is to initialize in of the basic block currBB
        Returns a dictinary {varName -> abstractValues}
        isStartNode is a flag for stating whether currBB is start basic block or not
    '''
    def initialize(self, currBB, isStartNode):
        val = {}
        #Your additional initialisation code if any
        if isStartNode:
            _tx, _ty = absNum(0), absNum(0)
            _dir = set([2])
            val = {'_tx':_tx, '_ty':_ty, '_dir': _dir}
            #print("1.initialized _tx {} _ty {} _dir {}".format(str(_tx),str(_ty),_dir))
        return val

    #just a dummy equallity check function for dictionary
    def isEqual(self, dA, dB):
        for i in dA.keys():
            if i not in dB.keys():
                return False
            if dA[i] != dB[i]:
                return False
        return True

    '''
        Transfer function for basic block 'currBB' 
        args: In val for currBB, currBB
        Returns newly calculated values in a form of list
    '''
    def transferFunction(self, currBBIN, currBB):
        #print("3.FA Transfer func currBBIN {} currBB {}".format([str(k)+':'+str(currBBIN[k]) for k in currBBIN], currBB))
        #implement your transfer function here
        for instr in currBB.instrlist:
            ins=instr[0]
            instype = type(ins)
            #print("in FA INSTRUCTION ==> {} <==".format(ins,instype))
            outVal=processIns(currBBIN.copy(),ins,instype)
        
        if str(currBB) == 'END': outVal = [currBBIN]
        #print("Transfer Function OutVal")
        #printDicts(outVal)
        return outVal

    '''
        Define the meet operation
        Returns a dictinary {varName -> abstractValues}
    '''
    def meet(self, predList):
        #print("\n2.In FA meet predList {}".format([[str(k)+':'+str(d[k]) for k in d] for d in predList]))
        assert isinstance(predList, list)
        meetVal = {}
        for pred in predList:
          for absvar in pred:
            if absvar not in meetVal.keys():          # If new variables are encountered, add them to the dictionary of abstract values.
              meetVal[absvar] = pred[absvar]
            else:                                     # Join with other branches abstract values
                if type(meetVal[absvar]) == Interval:
                  meetVal[absvar].join(pred[absvar])
                else:                                   # Else if direction is to be updated, add possible directions from predecessors.
                  meetVal[absvar]|=pred[absvar]         # Union all the directions, '|' is for set union.
        #print("2.1 In FA meet Updated predList {}".format([str(k)+':'+str(meetVal[k]) for k in meetVal]))
        return meetVal

def analyzeUsingAI(ir, filename):
    '''
        get the cfg outof IR
        each basic block consists of single statement
    '''
    cfg = cfgB.buildCFG(ir, "cfg", True)
    cfgB.dumpCFG(cfg, "x")
    
    # call worklist and get the in/out values of each basic block
    bbIn, bbOut = AI.worklistAlgorithm(cfg)
    '''print("InValues")
    for i in bbIn:
      print(i,bbIn[i])
    print("OutValues")
    for i in bbOut:
      print(i,end=" ")
      printDicts(bbOut[i])
      print()
    '''  
    
    #implement your analysis according to the questions on each basic blocks
    magRegFile=filename.replace(".tl",".json")
    xy = json.loads(open(magRegFile).read())
    xy = xy['reg']
    x1,y1,x2,y2 = xy[0][0],xy[0][1], xy[1][0],xy[1][1]
    mx = Interval((x1,x2))
    my = Interval((y1,y2))
    print("[+]Magarmach's Abstract Position x={} y={}".format(str(mx),str(my)))
    end = bbOut['END'][0]
    kx,ky = end['_tx'], end['_ty']
    print("[+]Kachua Abstract Position x={} y={}".format(kx,ky))
    mx.meet(kx)
    my.meet(ky)
    print("[+]Intersection x={} y={}".format(mx,my))
    safe = mx.isBot() or my.isBot()
    if safe:
      print("[+]Kachua is safe")
    else:
      print("[!}Kachua may rest in magarmach's region")
