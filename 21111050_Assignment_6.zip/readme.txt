Requirements:
1. Python3, antlr4-python3-runtime.
2. Code must be ran in bash shell for proper output.

Installations:
If the above requirements are not installed, install them using:
apt install python3
pip install antlr4-python3-runtime==4.7.2
sudo apt-get install python3-tk 

Running Instructions:
1. Run kachua.py  using:
	python3 kachua.py -ai testcases/case1.tl 

Working:
	1.Initialization is first done for turtle positions _tx and _ty and the direction which is initially left.
	Directions are given numerical values 0,1,2,3 for right,up,left,down resp.
	2.In meet function, the output values of predecessors is taken and a union of respective abstract values is performed.
	3. In transfer function, the previous output is taken and update to abstract values is made according to the instruction.
		For Assignment instructions => Abstract Value is assigned
		For Condition Commands => Respective functions for conditions are called like <=,>=,<,>,>=,== etc.
	Finally the output of END block is taken and checked with magarmach's region coordinates.
	If turtle may lie between magarmach region, it prints "may rest"
	Else we print "Safe"



Limitations:
	1. Infinity is assumed to be 99999(can be varied)

Assumptions:
1. submission.py is present in the folder Submission beside the current directory at the time of running, where other required
kachua packages also reside(like kachua.py,fuzzer etc)
2. Outputs of programs with json are provided in the folder testcases.
