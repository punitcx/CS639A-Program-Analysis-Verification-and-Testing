Requirements:
1. Python3, ast2json.
2. Code must be ran in bash shell for proper output.

Installations:
If the above requirements are not installed, install them using:
pip3 install ast2json
apt install python3

Running Instructions:
1. Make the run.sh file executable using:
	chmod +x run.sh
2. Pass the input python file as a parameter to run.sh using:
	./run.sh pythonfilename
	Ex: ./run.sh testcases/testcase1.py

Working:
	The script run.sh will invoke "assignment1.py" with the given parameter 
as an input python file and will dump the json. It will then output the 
assignment instructions, branch conditions and loop conditions.

Some complex testcases covering a variety of inputs are provided in the directory testcases.
Corresponding expected outputs are also provided in testcases.

Assumptions:
1. run.sh is present in current directory.
2. assignment1.py is present in the source directory and testcases are in testcases directory.
