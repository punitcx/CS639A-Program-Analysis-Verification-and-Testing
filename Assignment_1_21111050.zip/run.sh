#!/bin/bash
if [[ $# -lt 1 ]]
then
echo -e "Usage: $0 inputpythonfile"
else
python3 ./source/Assignment1.py $1
fi
