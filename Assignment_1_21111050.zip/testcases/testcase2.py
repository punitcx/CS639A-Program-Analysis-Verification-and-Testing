def load_data(dirtype):
  images,labels,filenames=[],[],[]
  dirlabelpaths=[os.path.join(dirtype,d) for d in os.listdir(dirtype) if os.path.isdir(os.path.join(dirtype,d))]
  for d in os.listdir(dirtype):
    if(os.path.isdir(os.path.join(dirtype,d))):
      for m in os.listdir(os.path.join(dirtype,d)):
      	labels.append(d)

  for dirlabelpath in dirlabelpaths:
    for f in os.listdir(dirlabelpath):
      if f.endswith(".jpg"):
        filenames.append(os.path.join(dirlabelpath,f))
  for f in filenames:
    im=images.append(np.array(cv2.resize(cv2.imread(f,1),(64,64)))/255)
  return np.array(images),np.array(labels)

images_train,labels_train=load_data("train/")
labels_train=labenc.fit_transform(labels_train)
labels_train=onehotenc.fit_transform(labels_train.reshape(-1,1))
slcnn.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
checkpoint = [ModelCheckpoint(filepath='models.hdf5')]
history = slcnn.fit(images_train, labels_train, batch_size=batch_size, epochs=epochs,callbacks=checkpoint, verbose=1,
                   validation_data=(images_test,labels_test))
slcnn.evaluate(images_test,labels_test)

def largestrect(contours):
	maxim=maxim2=mx2=my2=mw2=mh2=0
	for i in range(len(np.array(contours))):
		x,y,w,h = cv2.boundingRect(contours[i])
		if((w*h)>maxim):
			return mx,my,mw,mh  

cap=cv2.VideoCapture(0) # mobile cam using droidcam
ret,back=cap.read()
back=back[0:400,40:400]
t[:,:]=160
tc[:,:]=30

while(1):
	k = cv2.waitKey(1) & 0xFF
	ret,grdepc=cap.read()
	grdepc=grdepc[0:400,40:400]
	prod=((imgdiff1>=8)*(imgdiff2>=8))*255
	prod=np.array(prod).astype("uint8")#----------image differencing(detect moving pixels)--------
	imgdiff,contours,hierarchy=cv2.findContours(prod,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
	mx,my,mw,mh=largestrect(contours)

	back[my:my+mh,mx:mx+mw]=pc[my:my+mh,mx:mx+mw]
	t=((a*t)+(5*(1-a)*backsub)).astype("uint8")
	t[my:my+mh,mx:mx+mw]=tc[my:my+mh,mx:mx+mw]#--------------</update>
	for x in range(my,my+mh):
		for y in range(mx,mx+mw):
			ps=float(hs[hsvimg[x,y][0]]+ss[hsvimg[x,y][1]]+vs[hsvimg[x,y][2]])/(3*sums)
			pn=float(hn[hsvimg[x,y][0]]+sn[hsvimg[x,y][1]]+vn[hsvimg[x,y][2]])/(3*sumn)
			r=ps/pn
			if(r<=3):
				white[x,y]=255
							
