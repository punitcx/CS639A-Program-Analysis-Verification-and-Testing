#Basic Testcase
name = "punit"
a=input("\nEnter the value of a: ")
b = a =50
c+=21+b
output = fun.process(name, "hello",color=(red,blue,green,yellow))
a={1,2,3,4,"apple"}
test=[ord(c) for line in file for c in line]

lion=[1,2*3, bool(2),
(1 and 2) or 3, not 4,
"abcd"*10, [a for a in range(20)],(a,b,c,"dog",100)]

supernested=[1, "Hello", "World",
[2,34,5, "six", "seven"],
(a,b,c,"dog",100),
{"apple":"red","banana":"yellow", "bat": 1, "ball": 2, "games": ["hockey","kabaddi","chess","badminton"],
"numbers": (a,2,b,3,c,4,5,"seven"),
"india": {"maharashtra":("mumbai","pune","panvel","amravati"),"up":("kanpur","lucknow")},
"usa":{"Washington":("LA","MA City")}
}
]

elephants = [
    Elephant('mama', 5),
    Elephant('baby', 1),
    Elephant('grandma', 7),
    Elephant('daddy', 6),
    Elephant('son', 3),
]

with open('file_path', 'w') as file:
    if(2 and 3 == 4 and (1 <= a < 10)):
	    while(odd==3 and not(a)):
	    	file.write('hello world !')
def powers():
	while True or n==5 and (n > 6 & b<=2):
		if a==3 and b==4 and (a<b or b==2*a):
			fact = factorial(a)
		elif(a-b+c==4):
			fact = factorial(5)
		else:
			d= {x: x**2 for x in numbers}
