from PyQt5 import QtGui, QtCore, QtNetwork, QtWidgets
import time,sys,threading 
UA_STRING = """Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"""
software_names = [SoftwareName.CHROME.value]
operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]   
user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems, limit=100)

class myWebView(QtWebEngineWidgets.QWebEngineView):
    def __init__(self,usr,psr,rc,parent=False):
        self.data=None
    def recurring_timer(self):
        self.counter +=1
    def sks(self,data):
        rr=threading.Thread(target=self.processHTML(self.data), args=())
    def processHTML(self,data):
        for cc in range(0,1):
          self.kaj=self.page().url().toString()
          if 'aria-label="Send new message"' in str(self.data):
            try:
                cqf=open("good.txt","r")
                cqfr=cqf.readlines()
                for x in cqfr:
                    xc=str(x).replace("\n","")
                    xcdata.append(xc)
            except:
                xcdata=[]
            if str(self.usr) in str(xcdata):
                print("good ")
            else:
                filr=open('good.txt', 'a')
                crsv=csv.writer(filr,lineterminator='\n')
                crsv.writerow((str(self.usr),str(self.psr),str(self.rc)))
                filr.close()   
                print("good account")
                self.close()   
          if "https://voice.google.com/about"    in self.kaj:
            try:
                cqf=open("bad.txt","r")
                cqfr=cqf.readlines()
                cqf.close()
                xcdata=[]
                for x in cqfr:
                    xc=str(x).replace("\n","")
                    xcdata.append(xc)
            except:
                xcdata=[]
            if str(self.usr) in str(xcdata):
                print("bad ")
            else:
                filr=open('bad.txt', 'a')
                crsv=csv.writer(filr,lineterminator='\n')
                filr.close()   
class Ui_MainWindow(object):
    def setupUi(self, MainWindow,usr,psr,rc):
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.webView = myWebView(usr,psr,rc)
        web=self.webView.coook.cookieStore().deleteAllCookies()
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)

with open("userinfo.txt") as d:
    for x in d:
        xc=str(x).replace("\n","")
        rdatax.append(xc)
datax=[elem for elem in rdatax if elem not in ddrx ]
