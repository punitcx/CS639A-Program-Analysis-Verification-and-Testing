data = list(csv.reader(open('Airports.txt')))
airport={} #Dictionary
for line in data:# Each line in csv file
    airport[line[0]]=line   #airport[airportcode]=code,fullname,dist from Liverpool,dist from Bournemouth

aircraftTypedata={}
aircraftTypedata['MediumNarrow']={'Running Cost':8,'Maximum Range': 2650,'Capacity standard class': 180,'Minimum firstclass seats': 8}
aircraftTypedata['LargeNarrow']={'Running Cost':7,'Maximum Range': 5600,'Capacity standard class': 220,'Minimum firstclass seats': 10}
aircraftTypedata['MediumWide']={'Running Cost':5,'Maximum Range': 4050,'Capacity standard class': 406,'Minimum firstclass seats': 14}

allowedtypes=aircraftTypedata.keys()  #Allowed aircraft types(MediumNarrow,LargeNarrow,MediumWide)
uklocation=['Liv','Bou']
def enterLocationDetails():
    global codeuk,codeos
    codeuk=input("Enter the three-letter airport code for the UK location: ")
    if(codeuk not in uklocation):
        print("The code entered is not appropriate")#Show messages.
        return;
    if(codeos in codes):
        print("Full name of code ",codeos,"is :",airport[codeos][1]) # 1 means full name.
    else:
        print("The Code for overseas airport is not valid") #Show messages.
        return;

def enterJourneyDetails():
    global aircraftType,firstcseats,totalStandSeats
    option=int(input("Enter the type of Aircraft to use: 1.MediumNarrow 2.LargeNarrow 3.MediumWide"))
    if(option==1):
        aircraftType='MediumNarrow'
    if(option==2):
        aircraftType='LargeNarrow'
    if(option==3):
        aircraftType='MediumWide'
    if(aircraftType not in allowedtypes):
        print("The Aircraft type is not valid.")
        return;

    minfirstcseats=aircraftData['Minimum firstclass seats']
    allStandClassCapacity=aircraftData['Capacity standard class']
    firstcseats=int(input("Enter the number of first class seats: "))
    
    if(firstcseats!=0):
        if(firstcseats < minfirstcseats):
            print("The seats cannot be less than minimum first class seats")
            return;
        if(firstcseats>0.5*(allStandClassCapacity)):
            print("first-class seats cannot be greater than half the capacity when all seats are standardclass")
            return;
        totalStandSeats=(allStandClassCapacity-firstcseats*2)
        print("Total Standard Class Seats: ",totalStandSeats)
        return; # return

def calculateProfit():
    global distBetnAirports
    if(codeuk=='' or codeos==''):
        print("No code is entered for UK or Overseas")
        return;
    if(codeuk=='Liv'):
        distBetnAirports=airport[codeos][2] #2 means distance from Liverpool
    if(codeuk=='Bou'):
        distBetnAirports=airport[codeos][3] #3 means distance from Bournemouth
    maxJourneyRange=aircraftTypedata[aircraftType]['Maximum Range']
    costSeat100km=int(aircraftTypedata[aircraftType]['Running Cost'])
    if(maxJourneyRange<int(distBetnAirports)):
    	standClassPrice=int(input("Enter Standard Class Seat Price: "))
    	firstClassPrice=int(input("Enter First Class Seat Price: "))

    journeyCostPerSeat=costSeat100km * int(distBetnAirports) / 100.0
    journeyCost=journeyCostPerSeat * (firstcseats + totalStandSeats)
    journeyIncome=firstcseats*firstClassPrice + totalStandSeats*standClassPrice
    journeyProfit=journeyIncome - journeyCost

    print("Journey Cost Per Seat: ", journeyCostPerSeat)
    print("Journey Cost: ", journeyCost)
    print("Journey Income: ", journeyIncome)
    print("JourneyProfit: ",journeyProfit)
    return;

while(True):  # Keep on executing what is written below it.
    print('1.Enter Location Details')
    print('2.Enter journey details.')
    print('3.Enter price plan and calculate profit.')
    print('4.Clear Data.')
    print('5.Quit')

    option=int(input("Select a choice : "))

    if(option==1):
        enterLocationDetails(); # If option 1
    elif(option==2):
        enterJourneyDetails();  # If option 2
    elif(option==3):
        calculateProfit(); # If option 3
    elif(option==4):      
        clearData();       # If option 4
    elif(option==5):
        exit();   # If option is 5 Exit.
    else:
        print("Choose a valid option. ")  #Else choose a valid option
