#!/bin/python3
# Approach: Tries to build the original python code from AST and while building recursively, it identifies the assignments, branches and loops.
import sys,json
from ast import parse
from ast2json import ast2json				# Import ast2json and str2json(to show readable json output)
from ast2json import str2json

if len(sys.argv)<2:
	exit(0)

filename=sys.argv[1]					# Take argument as filename to analyze.

assignments,branches,loops=[],[],[]			# Declare lists for storing assignments, branches and loops.

# Types of possible operators in python.
oper_map={ 'And' : 'and', 'Or': 'or', 'Add' : '+', 'Sub' : '-', 'Mult' : '*', 'MatMult' : '@', 'Div' : '/', 'Mod' : '%',
'Pow' : '**', 'LShift': '<<', 'RShift' : '>>', 'BitOr' : '|', 'BitXor' : '^', 'BitAnd' : '&', 'FloorDiv' : '//', 'Invert' : '',
'Not' : 'not', 'UAdd' : '+', 'USub' : '-', 'Eq' : '==', 'NotEq' : '!=', 'Lt' : '<', 'LtE' : '<=', 'Gt' : '>', 'GtE' : '>=',
'Is' : 'is', 'IsNot' : 'is not', 'In' : 'in', 'NotIn' : 'not in'}

assignment=''

def processAssign(element):													# Type 'Assign" in AST has the fields targets,value.
	_targets=element['targets']
	targets=[build(target) for target in _targets]
	value=build(element['value'])	
	assignment = "{} = {}".format('='.join(targets),value)
	assignments.append(assignment)
	return assignment

def processAnnAssign(element):											# Element 'AnnAssign' has keys annotation, target and value fields which is built recursively.
	annotation=build(element['annotation'])
	target=build(element['target'])
	value=element['value']
	if value == None:
		assignment = '{}: {}'.format(target,annotation)
	else:
		value=build(value)
		assignment = '{}: {} = {}'.format(target,annotation,value)
	assignments.append(assignment)
	return assignment

def processAugAssign(element):								# Assignments of the type b += 2 , where target=b, op= +, value= 2.
	target=build(element['target'])
	value=build(element['value'])	
	op=build(element['op'])
	assignment = "{} {}= {}".format(target,op,value)
	assignments.append(assignment)
	return assignment

def processList(element):											# _type = List
	elts=element['elts']												# 'elts' contains the array of elements in the list.
	elements=[build(elt) for elt in elts]
	return '[{}]'.format(','.join(elements))

def processTuple(element):										# _type = Tuple
	elts=element['elts']												# 'elts' contains the array of elements in the Tuple.
	elements=[build(elt) for elt in elts]
	return '({})'.format(','.join(elements))

def processSet(element):											# _type = Set
	elts=element['elts']												# 'elts' contains the array of elements in the Set.
	elements=[build(elt) for elt in elts]
	return '{{{}}}'.format(','.join(elements))

def processDict(element):																	# _type = Dict
	keys=[build(key) for key in element['keys']]						# Dict has children as 'keys' and 'values' which are array of keys and respective values.
	values=[build(value) for value in element['values']]
	dct=[keys[i]+':'+values[i] for i in range(len(keys))]
	return '{{{}}}'.format(','.join(dct))
	
def processSlice(element):											# _type = Slice
	lower=build(element['lower'])									# Slice operator which has children as lower, upper and step				
	upper=build(element['upper'])									# Ex: array[3:15:1]
	step=build(element['step'])
	if step !='':
		return '{}'.format(':'.join([lower,upper,step]))
	else:
		return '{}'.format(':'.join([lower,upper]))

def processBinOp(element):											# _type = BinOp
	left=build(element['left'])										# Any python binary operaton which has left and right child as its operands.
	op=build(element['op'])												# Ex: 3 + 4, 2 * 3
	right=build(element['right'])
	return '({})'.format(left+op+right)

def processBoolOp(element):											# _type = BoolOp
	op=build(element['op'])												# Boolean operaton like and, or etc.
	values=element['values']											# Ex: a and b, a or b, b and c 
	vals= [build(value) for value in values]
	vals= '({})'.format(op.join(vals))
	return vals

def processUnaryOp(element):										# _type == UnaryOp
	op=build(element['op'])												# op will be the Unary Operand +,- etc.
	operand=build(element['operand'])							# Operand will be a constant or a variable.
	return op+operand															# Ex: +2, -3
	
def processListComp(element):											# _type = ListComp
	elt=build(element['elt'])												# List Generators in python like [a for a in range(10)] 
	generators=element['generators']
	comprehensions=[build(comp) for comp in generators]
	comprehensions=' '.join(comprehensions)
	return '[{} {}]'.format(elt,comprehensions)

def processSetComp(element):											# _type = SetComp
	elt=build(element['elt'])												# Set Generators in python like {x: x for x in numbers}
	generators=element['generators']
	comprehensions=[build(comp) for comp in generators]
	comprehensions=' '.join(comprehensions)
	return '{{{} {}}}'.format(elt,comprehensions)

def processDictComp(element):											# _type = DictComp
	generators=element['generators']								# Dictionary Generators in python like {x: x**2 for x in numbers}
	comprehensions=[build(comp) for comp in generators]
	key=build(element['key']);											# In the above example x is key and x**2 is value.
	value=build(element['value'])
	comprehensions=' '.join(comprehensions)
	return '{{{}:{} {}}}'.format(key,value,comprehensions)

def processComprehension(element):								# _type = Comprehension
	iterfunc=build(element['iter'])									# Ex: [ord(c) for line in file for c in line]
	target=build(element['target'])
	ifs=[build(ifcond) for ifcond in element['ifs']]
	comp='for {} in {}'.format(target,iterfunc)
	comp+=' if ' + ' '.join(ifs) if len(ifs) !=0 else ''
	return comp

def processAttribute(element):										# _type = Attribute
	attr=element['attr']											# Ex: student.name where name is an attribute.
	value=build(element['value'])
	return '{}.{}'.format(value,attr)

def processKeyword(element):											# _type = Keyword
	arg=element['arg']															# Providing arguments to function like multiply(a=2, b=3)
	value=build(element['value'])
	return '{}={}'.format(arg,value)

def processRaise(element):												# _type = Raise
	cause=build(element['cause'])
	exc=build(element['exc'])
	return 'raise {} from {}'.format(exc,cause)
	
def processAssert(element):												# _type = Assert
	msg=build(element['msg'])
	test=build(element['test'])
	return 'assert {},{}'.format(test,msg)

def processDelete(element):												# _type = Delete
	targets=[build(targ) for targ in element['targets']]
	return 'delete {}'.format(','.join(targets))

def processPass(element):												# _type = Pass
	return "pass"

def processExpr(element):												# _type = Expr
	value=build(element['value'])									# Expression like -2, -b, +c
	return value

def processIfExp(element):												# _type = IfExp
	test=build(element['test'])											# Statements of the type a if b else c
	branches.append(test)
	body=build(element['body'])
	orelse=build(element['orelse'])
	return '{} if {} else {}'.format('\n'.join(body),test,orelse)

def processCompare(element):												# _type = Compare
	comparators=[build(comp) for comp in element['comparators']]
	left=build(element['left'])
	ops=[build(op) for op in element['ops']]
	comp=[ops[i]+comparators[i] for i in range(len(ops))]    #	Comparison statement like 1 <= a < 10 which left=1, op= <= and comparators=10. 
	return "{}".format(left+''.join(comp))

def processYield(element):													# _type = Yield
	value=build(element['value'])
	return 'yield {}'.format(value)

def processFunctionDef(element):										# _type = FunctionDef
	body=[build(cont) for cont in element['body']]		# A function definition which has body and arguments.
	return '{}'.format('\n'.join(body))

def processClassDef(element):												# _type = ClassDef
	body=[build(part) for part in element['body']]		# A Definition of class in python which has body as its contents.
	return "ClassDef"

def processWhile(element):													# _type = While
	test=build(element['test'])												# While loop in python with test condition and its contents stored in body.
	loops.append(test)
	body=[build(part) for part in element['body']]
	orelse=[build(part) for part in element['orelse']]
	return 'While {}:\n{}'.format(test,'\n'.join(body))

def processFor(element):																	# _type = For
	iterator=build(element['iter'])													# iterator is ex: range(10)
	orelse=[build(part) for part in element['orelse']]			
	target=build(element['target'])													# target is the variable which needs to be checked for condition.
	loops.append('{} in {}'.format(target,iterator))
	body=[build(part) for part in element['body']]					# A for loop in python where the content is stored in body.
	return 'for {} in {}:\n{}'.format(target,iterator,'\n'.join(body))

def processIf(element):																	# _type = If
	test=build(element['test'])														# Python if elif else branch.
	branches.append(test)																	# test is the if condition
	body=[build(part) for part in element['body']]				# body is the body to be executed if the condition is true
	orelse=[build(part) for part in element['orelse']]		# elif or else part for if.
	return 'if {}:\n{} \nelse:\n {}'.format(test,'\n'.join(body),'\n'.join(orelse))

def processWith(element):																# _type = With
	body=[build(part) for part in element['body']]				# With in python having the contents in body.
	return "With"

def processArguments(element):													# _type = Arguments
	args=[arg['arg'] for arg in element['args']]
	return ','.join(args)
	
def processSubscript(element):													# _type = Subscript
	Slice=build(element['slice'])													# Subscript can be like image[1:2, 3]
	value=build(element['value'])
	return '{}[{}]'.format(value,Slice)

def processCall(element):																# _type = Call
	func=build(element['func'])														# It is a function call having arguments and keywords.
	args=element['args']
	args=[build(ar) for ar in args]
	args+=[build(keyw) for keyw in element['keywords']]
	args=','.join(args)
	return '{}({})'.format(func,args)
	
def processLambda(element):
	body=build(element['body'])
	args=build(element['args'])
	return 'lambda {} : {}'.format(args,body)

def processIter(element):																# _type = Iter
	processCall(element)																	# Iterative in python Ex: int(2), range(10) 

#This is the main build function which does traversal on the tree.
def build(element):			# Checks the corresponding type and traverses the subtree by calling its corresponding process function. 
	if element is None or type(element) is type(list()):
		return ''
	_type=element['_type']
	if _type == "Constant":
		return '"{}"'.format(element['value'].replace("\n","\\n")) if type(element['value']) == str else str(element['value'])
	elif _type == "Name":
		return str(element['id'])
	elif _type == "BinOp":
		return processBinOp(element)
	elif _type == "Assign":
		return processAssign(element)
	elif _type == "AnnAssign":
		return processAnnAssign(element)
	elif _type == "AugAssign":
		return processAugAssign(element)
	elif _type == "List":
		return processList(element)
	elif _type == "Tuple":
		return processTuple(element)
	elif _type == "Set":
		return processSet(element)
	elif _type == "Dict":
		return processDict(element)
	elif _type == "Slice":
		return processSlice(element)	
	elif _type == "BoolOp":
		return processBoolOp(element)
	elif _type == "UnaryOp":
		return processUnaryOp(element)
	elif _type == "ListComp":
		return processListComp(element)
	elif _type == "SetComp":
		return processSetComp(element)
	elif _type == "DictComp":
		return processDictComp(element)
	elif _type == "comprehension":
		return processComprehension(element)
	elif _type == "Attribute":
		return processAttribute(element)
	elif _type == "keyword":
		return processKeyword(element)
	elif _type == "Iter":
		return processIter(element)
	elif _type == "Call":
		return processCall(element)
	elif _type == "Lambda":
		return processLambda(element)
	elif _type == "FunctionDef":
		return processFunctionDef(element)
	elif _type == "ClassDef":
		return processClassDef(element)
	elif _type == "Raise":
		return processRaise(element)
	elif _type == "Assert":
		return processAssert(element)
	elif _type == "Delete":
		return processDelete(element)
	elif _type == "Pass":
		return processPass(element)
	elif _type == "Expr":
		return processExpr(element)
	elif _type == "IfExp":
		return processIfExp(element)
	elif _type == "While":
		return processWhile(element)
	elif _type == "For":
		return processFor(element)
	elif _type == "If":
		return processIf(element)
	elif _type == "With":
		return processWith(element)
	elif _type == "arguments":
		return processArguments(element)
	elif _type == "Subscript":
		return processSubscript(element)
	elif _type == "Yield":
		return processYield(element)
	elif _type == "Compare":
		return processCompare(element)
	elif _type in oper_map.keys():
		return ' {} '.format(oper_map[_type])
	elif 'body' in element.keys():
		return build(element['body'])
	return '{}'.format(_type)												# If the type is not defined, simply return the type in the output.

def printDump(body):															# Recursive function to keep traversing nested body items.
	for element in body:
		build(element)																# build will take an element and build it recursively.

dump=str2json(open(filename).read())		# Get AST in json format.
body=dump["body"]				# First set of children in AST.
printDump(body)					# Call the recursive function.

print("\n------------OUTPUT-------------") 					#Finally print the stored assignment statements, branch statements and loops.
print("Assignments: \n\t{} \n\nBranch Conditions: \n\t{} \n\nLoop Conditions: \n\t{}\n".format('\n\t'.join(assignments),'\n\t'.join(branches),'\n\t'.join(loops)))

#ast = ast2json(parse(open(filename).read()))
#print("AST JSON Dump:\n",json.dumps(ast, indent=4))	# Uncomment to get AST in json in a readable format.
