from z3 import *
import argparse
import json
import sys
sys.path.insert(0, '../KachuaCore/')
from sExecutionInterface import *
import z3solver as zs
from irgen import *
from interpreter import *
import ast

def example(s):
    # To add symbolic variable x to solver
    s.addSymbVar('x')
    s.addSymbVar('y')
    s.addSymbVar('c1')
    s.addSymbVar('c2')
    # To add constraint in form of string
    s.addConstraint('And(Not(x<=42),y==x+22,y==x+c2)')
    #s.addConstraint('And(x!=y,x>5)')
    # s.addConstraint('Implies(x==4,y==x+8')
    # To access solvers directly use s.s.<function of z3>()
    print("constraints added till now",s.s.assertions())
    
    # To assign z=x+y
    #s.addAssignment('z','x+y')
    # To get any variable assigned
    #print("variable assignment of z =",s.getVar('z'))
    help(s.s)
    print("Checking :",s.s.check())
    print("Solved:",s.s.model())
    s.addConstraint('And(x<=42,y==x+40,y==x+c1+c2)')
    print("Checking :",s.s.check())
    print("Solved:",s.s.model())

def replaceParams(testData1,testData2,output):  # After generating the test cases, replace the values of parameters like x, y in symbEnc with their actual values
  for index in testData1:                       # in 1st json.
    for param in testData1[index]['params']:
      rhsparam=testData1[index]['params'][param]
      for var in testData1[index]['symbEnc']:
        rhs=testData1[index]['symbEnc'][var]
        if param in rhs and param in output: testData1[index]['symbEnc'][var] = rhs.replace(param,str(rhsparam))

  for index in testData2:                       # After generating the test cases, replace the values of parameters like x, y in symbEnc with their actual values
    for param in testData1[index]['params']:    
      rhsparam=testData1[index]['params'][param] # Replace the same values in 2nd json symbEnc parameters.
      for var in testData2[index]['symbEnc']:
        rhs=testData2[index]['symbEnc'][var]
        if param in rhs and param in output: testData2[index]['symbEnc'][var] = rhs.replace(param,str(rhsparam))
  return testData1,testData2

def paramsToEquation(params,constraints):
  eqn=[]
  for var in params:
    eqn.append('{}=={}'.format(var,str(params[var])))
  eqn+=constraints
  return ','.join(eqn)

def match(eqn,params,s):      # Check if parameters of 1st json file at particular index satisfy the constraints
  s.s.reset()                 # at some other index in 2nd json file. If they match, add them for solving since they are equal paths.
  eqn='And({})'.format(eqn)
  [s.addSymbVar(var) for var in params]
  s.addConstraint(eqn)
  matched=str(s.s.check())               # Check if the constraints are satisfiable or not.
  #print('Check Match',eqn,matched)
  return matched == 'sat'

def formEquation(assg1,assg2,eqn):
  for var1 in assg1:                     # Match the variables from json and form the equation.
    for var2 in assg2:
      if var1 == var2: eqn.append('{}=={}'.format(str(assg1[var1]),str(assg2[var2])))
  return eqn

def solveEquations(final,params,s):
  s.s.reset()
  final=','.join(final)                             # Concatenate all the equations for solving.
  final='And({})'.format(final)
  [s.addSymbVar(var) for var in params]             # Add all the parameters as symbolic variables like x, y, c1, c2, c3 etc.
  s.addConstraint(final)                            # Add final equations for solving.
  #print('Params',params.keys())
  matched= str(s.s.check())
  print('Solving The Equations:',final,matched)      # Check if solution exists and solve using z3Solver.
  if matched == 'sat': print('\nSolution: ',s.s.model())

def matchPaths(testData1,testData2,s):   # Match the parameters of 1st json file with Constraints of 2nd file.
  final=[]
  for ind1 in testData1:
    for ind2 in testData2:
      params=testData1[ind1]['params']
      constraints=testData2[ind2]['constraints']
      eqn=paramsToEquation(params,constraints)       # Convert parameters to equation for solving.
      matched=match(eqn,params,s)                    # Check if the paths are matched or not, if yes then add them for solving.
      if matched:
        #print("Indexes",ind1,ind2)
        final=formEquation(testData1[ind1]['symbEnc'],testData2[ind2]['symbEnc'],final)
  solveEquations(final,params,s)

def checkEq(args,ir):

    file1 = open("../Submission/testData1.json","r+")   # Open 1st json file
    testData1=json.loads(file1.read())
    file1.close()
    s = zs.z3Solver()
    testData1 = convertTestData(testData1)
    
    file2 = open("../Submission/testData2.json","r+")  # Open 2nd json file
    testData2=json.loads(file2.read())
    file2.close()
    s = zs.z3Solver()
    testData2 = convertTestData(testData2)
    #print('Testdata: {} \n {}'.format(testData1,testData2))
    
    output = args.output
    testData1,testData2=replaceParams(testData1,testData2,output)  # Replace parameters in symEnc with the actual values of test cases.
    matchPaths(testData1,testData2,s)   # Match the paths using parameters for 1st json file and constraints for 2nd json file and add for solving.
    #example(s)
    # TODO: write code to check equivalence
if __name__ == '__main__':
    cmdparser = argparse.ArgumentParser(
        description='symbSubmission for assignment Program Synthesis using Symbolic Execution')
    cmdparser.add_argument('progfl')
    cmdparser.add_argument(
        '-b', '--bin', action='store_true', help='load binary IR')
    cmdparser.add_argument(
        '-e', '--output', default=list(), type=ast.literal_eval,
                               help="pass variables to kachua program in python dictionary format")
    args = cmdparser.parse_args()
    ir = loadIR(args.progfl)
    checkEq(args,ir)
    exit()
