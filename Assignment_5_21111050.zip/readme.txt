Requirements:
1. Python3, antlr4-python3-runtime.
2. Code must be ran in bash shell for proper output.

Installations:
If the above requirements are not installed, install them using:
apt install python3
pip install antlr4-python3-runtime==4.7.2
sudo apt-get install python3-tk 

Running Instructions:
1. Run kachua.py with both the files for semantic execution using:
	Ex ./kachua.py -t 100 -se testcases/case61.tl -d "{':x':20, ':y': 50}" -c "{':c1': 1, ':c2':1, ':c3':1}"
	./kachua.py -t 100 -se testcases/case62.tl -d "{':x':20, ':y': 30}" -c "{':c1': 1, ':c2':1, ':c3':1}"

Working:
	kachua.py will invoke function checkEq from submission.py which will check and derive the values for constraints which make the two programs
	semantically equal.

Cases:
	Some complex testcases covering a variety of inputs are provided in the directory testcases.
	Run using:
	1]./kachua.py -t 100 -se testcases/case61.tl -d "{':x':20, ':y': 50}" -c "{':c1': 1, ':c2':1, ':c3':1}"
	2]mv ../Submission/testData.json ../Submission/testData1.json
	3]./kachua.py -t 100 -se testcases/case62.tl -d "{':x':20, ':y': 30}" -c "{':c1': 1, ':c2':1, ':c3':1}"
	4]mv ../Submission/testData.json ../Submission/testData2.json
	5]python3 ../Submission/symbSubmission.py -b optimized.kw -e '["x","y"]

Outputs of pairwise equivalent programs are provided in the folder testcases.

Limitations:
	1. Loop unrolling is time bound, so the program will unroll repeat loops until the specified time is reached, so time needs to be adjusted for repeat loops. Or simply, the working is limited for repeat loops.

Assumptions:
1. submission.py is present in the folder Submission beside the current directory at the time of running, where other required
kachua packages also reside(like kachua.py,fuzzer etc)
